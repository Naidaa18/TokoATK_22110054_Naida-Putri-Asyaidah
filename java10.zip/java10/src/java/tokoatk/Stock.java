package tokoatk;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;

public class Stock {
    private String id;
    private LocalDateTime waktu;
    private String username;

    // Getter
    public String getId() {
        return id;
    }

    public LocalDateTime getWaktu() {
        return waktu;
    }

    public String getUsername() {
        return username;
    }

    // Baca berdasarkan ID
    public boolean baca(String id) {
        try (Connection conn = DbConnection.connect()) {
            String sql = "SELECT * FROM stockm WHERE id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                this.id = rs.getString("id");
                this.username = rs.getString("username");
                this.waktu = rs.getTimestamp("waktu").toLocalDateTime();
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // Tambah stock baru
    public boolean tambah(String username) {
        try (Connection conn = DbConnection.connect()) {
            this.id = "STK" + System.currentTimeMillis();
            this.username = username;
            this.waktu = LocalDateTime.now();

            String sql = "INSERT INTO stockm (id, waktu, username) VALUES (?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            ps.setTimestamp(2, Timestamp.valueOf(waktu));
            ps.setString(3, username);

            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Hapus data stock
    public boolean hapus() {
        try (Connection conn = DbConnection.connect()) {
            // Hapus detail dulu
            String sql = "DELETE FROM stockd WHERE stockId=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            ps.executeUpdate();

            // Hapus master-nya
            sql = "DELETE FROM stockm WHERE id=?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            ps.executeUpdate();

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Tambah detail
    public boolean addDetail(String barangId, Integer qty, Integer harga) {
        return new StockDetail().tambah(this.id, barangId, qty, harga);
    }

    // Ambil semua detail dari stock ini
    public ArrayList<StockDetail> getDetail() {
        return StockDetail.getListByStockId(this.id);
    }

    // Ambil semua record stock
    public static ArrayList<Stock> getList() {
        ArrayList<Stock> list = new ArrayList<>();
        try (Connection conn = DbConnection.connect()) {
            String sql = "SELECT * FROM stockm ORDER BY waktu DESC";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Stock stock = new Stock();
                stock.id = rs.getString("id");
                stock.username = rs.getString("username");
                stock.waktu = rs.getTimestamp("waktu").toLocalDateTime();
                list.add(stock);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
