package tokoatk;

import java.sql.*;
import java.util.ArrayList;

public class User {

    private String username;
    private String fullname;

    // Constructor
    public User() {}

    public User(String username, String fullname) {
        this.username = username;
        this.fullname = fullname;
    }

    // Getter
    public String getUsername() {
        return this.username;
    }

    public String getFullname() {
        return this.fullname;
    }

    // Setter
    public void setUsername(String username) {
    this.username = username;
}

public void setFullname(String fullname) {
    this.fullname = fullname;
}


    // Login method
    public boolean login(String username, String password) {
        Connection conn = null;
        PreparedStatement st;
        ResultSet rs;

        try {
            conn = DbConnection.connect();
            String sql = "SELECT * FROM users WHERE username=? AND MD5(?)=password";
            st = conn.prepareStatement(sql);
            st.setString(1, username);
            st.setString(2, password);
            rs = st.executeQuery();

            if (rs.next()) {
                this.username = rs.getString("username");
                this.fullname = rs.getString("fullname");
                return true;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    // Read user data
    public boolean baca(String username) {
        Connection conn = null;
        PreparedStatement st;
        ResultSet rs;

        try {
            conn = DbConnection.connect();
            String sql = "SELECT * FROM users WHERE username=?";
            st = conn.prepareStatement(sql);
            st.setString(1, username);
            rs = st.executeQuery();

            if (rs.next()) {
                this.username = rs.getString("username");
                this.fullname = rs.getString("fullname");
                return true;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    // Get user by username (static)
    public static User getByUsername(String username) {
        User user = new User();
        if (user.baca(username)) {
            return user;
        } else {
            return null;
        }
    }

    // Check if username exists
    public boolean isUsernameExist() {
        try (Connection conn = DbConnection.connect()) {
            String sql = "SELECT username FROM users WHERE username=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (Exception ex) {
            ex.printStackTrace();
            return true;
        }
    }

    // Add new user
    // ✅ INI SAJA YANG DIPERTAHANKAN
public boolean tambah(String password) {
    System.out.println("Menambahkan user: " + username + ", " + fullname + ", password: " + password);

    if (isUsernameExist()) {
        System.out.println("Username sudah ada");
        return false;
    }

    try (Connection conn = DbConnection.connect()) {
        String sql = "INSERT INTO users (username, fullname, password) VALUES (?, ?, MD5(?))";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, username);
        ps.setString(2, fullname);
        ps.setString(3, password);
        ps.executeUpdate();
        return true;
    } catch (Exception ex) {
        ex.printStackTrace();  // << penting
        return false;
    }
}


    // Update user fullname
    public boolean update() {
        try (Connection conn = DbConnection.connect()) {
            String sql = "UPDATE users SET fullname=? WHERE username=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, fullname);
            ps.setString(2, username);
            ps.executeUpdate();
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }

    // Update user password
    public boolean updatePassword(String password) {
        try (Connection conn = DbConnection.connect()) {
            String sql = "UPDATE users SET password=MD5(?) WHERE username=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, password);
            ps.setString(2, username);
            ps.executeUpdate();
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }


    // Delete user
    public boolean hapus() {
        try (Connection conn = DbConnection.connect()) {
            String sql = "DELETE FROM users WHERE username=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, username);
            ps.executeUpdate();
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }

    // Get all users
    public static ArrayList<User> getList() {
        ArrayList<User> list = new ArrayList<>();
        try (Connection conn = DbConnection.connect()) {
            String sql = "SELECT * FROM users";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                User user = new User();
                user.setUsername(rs.getString("username"));
                user.setFullname(rs.getString("fullname"));
                list.add(user);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return list;
    }
}