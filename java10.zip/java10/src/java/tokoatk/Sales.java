package tokoatk;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class Sales {
    private String id;
    private String username;
    private String tanggal;
    // tambahkan field waktu kalau perlu

    // Getter & Setter
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getTanggal(){return tanggal;}

    // Baca data sales berdasarkan id
    public boolean baca(String id) {
    try (Connection conn = DbConnection.connect()) {
        String sql = "SELECT * FROM salesm WHERE id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, id);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
    this.id = rs.getString("id");
    this.username = rs.getString("username");

    // Coba baca kolom waktu (jika memang tidak ada tanggal)
    try {
        this.tanggal = rs.getString("waktu"); // ✅ sesuaikan dengan struktur tabel
    } catch (Exception ignore) {
        this.tanggal = "-";
    }

    return true;
}

    } catch (Exception e) {
        e.printStackTrace();
    }
    return false;
}


    // Dapatkan list semua sales
    public static ArrayList<Sales> getList() {
        ArrayList<Sales> list = new ArrayList<>();
        String sql = "SELECT * FROM salesm";
        try (Connection conn = DbConnection.connect();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Sales s = new Sales();
                s.id = rs.getString("id");
                s.username = rs.getString("username");
                list.add(s);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Tambah data sales
   public void tambah(String username) {
    try {
        Connection conn = DbConnection.connect();

        this.id = "SLS" + System.currentTimeMillis(); // format id lebih bagus
        String sql = "INSERT INTO salesm (id, username, waktu) VALUES (?, ?, NOW())";
        PreparedStatement st = conn.prepareStatement(sql);
        st.setString(1, this.id);
        st.setString(2, username); // ini harus admin / user valid

        st.executeUpdate();
        this.username = username;

        conn.close();
    } catch (Exception ex) {
        ex.printStackTrace(); // LIHAT DI LOG TOMCAT
    }
}




    // Hapus sales
    public boolean hapus() {
        String sql = "DELETE FROM salesm WHERE id = ?";
        try (Connection conn = DbConnection.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, this.id);
            int rows = ps.executeUpdate();
            return rows > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Ambil detail sales dari SalesDetail
    public ArrayList<SalesDetail> getDetail() {
    try {
        return SalesDetail.getBySalesId(this.id);
    } catch (Exception e) {
        e.printStackTrace();
        return new ArrayList<>();
    }
}

 public boolean addDetail(String barangId, int qty, int harga) {
    String sql = "INSERT INTO salesd (salesid, barangid, qty, harga) VALUES (?, ?, ?, ?)";
    try (Connection conn = DbConnection.connect();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, this.id);        // pastikan this.id sudah berisi salesId
        ps.setString(2, barangId);
        ps.setInt(3, qty);
        ps.setInt(4, harga);
        int inserted = ps.executeUpdate();
        return inserted > 0;
    } catch (Exception e) {
        e.printStackTrace();  // ini penting agar tahu error sebenarnya
        return false;
    }
}





}