package tokoatk;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class Barang {
    private String id;
    private String nama;
    private String jenis;
    private Integer harga;
    private Integer stok;

    private void hapusRelasi(Connection conn) throws Exception {
        // Hapus dari tabel yang berkaitan
        String sql1 = "DELETE FROM stockd WHERE barangId = ?";
        PreparedStatement ps1 = conn.prepareStatement(sql1);
        ps1.setString(1, this.id);
        ps1.executeUpdate();

        String sql2 = "DELETE FROM salesd WHERE barangId = ?";
        PreparedStatement ps2 = conn.prepareStatement(sql2);
        ps2.setString(1, this.id);
        ps2.executeUpdate();
    }

    // Constructors
    public Barang() {}

    public Barang(String id, String nama, String jenis, Integer harga) {
        this.id = id;
        this.nama = nama;
        this.jenis = jenis;
        this.harga = harga;
    }

    // Getters
    public String getId() { return id; }
    public String getNama() { return nama; }
    public String getJenis() { return jenis; }
    public Integer getHarga() { return harga; }
    public Integer getStok() { return stok; }

    // Setters
    public void setId(String id) { this.id = id; }
    public void setNama(String nama) { this.nama = nama; }
    public void setJenis(String jenis) { this.jenis = jenis; }
    public void setHarga(Integer harga) { this.harga = harga; }
    public void setStok(Integer stok) { this.stok = stok; }

    // Tambah barang
    public boolean tambah() {
        try (Connection conn = DbConnection.connect()) {
            String sql = "INSERT INTO barang (id, nama, jenis, harga, stok) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, this.id);
            ps.setString(2, this.nama);
            ps.setString(3, this.jenis);
            ps.setInt(4, this.harga);
            ps.setInt(5, this.stok);
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            System.out.println("ERROR TAMBAH BARANG: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    // Baca barang berdasarkan ID
    public boolean baca(String id) {
        try (Connection conn = DbConnection.connect()) {
            String sql = "SELECT * FROM barang WHERE id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                this.id = rs.getString("id");
                this.nama = rs.getString("nama");
                this.jenis = rs.getString("jenis");
                this.harga = rs.getInt("harga");
                this.stok = rs.getInt("stok");
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // Versi update stok tanpa parameter koneksi (bisa dipanggil langsung)
    public boolean updateStok(String barangId, int stokBaru) {
        String sql = "UPDATE barang SET stok = ? WHERE id = ?";
        try (Connection conn = DbConnection.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, stokBaru);
            ps.setString(2, barangId);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // Versi update stok dengan parameter koneksi (untuk efisiensi, dipakai di kurangiStok)
    private boolean updateStok(Connection conn, String barangId, int stokBaru) {
        String sql = "UPDATE barang SET stok = ? WHERE id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, stokBaru);
            ps.setString(2, barangId);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    // Update data barang
public boolean update() {
    try (Connection conn = DbConnection.connect()) {
        String sql = "UPDATE barang SET nama = ?, jenis = ?, harga = ?, stok = ? WHERE id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, this.nama);
        ps.setString(2, this.jenis);
        ps.setInt(3, this.harga);
        ps.setInt(4, this.stok != null ? this.stok : 0); // kalau stok null, set 0
        ps.setString(5, this.id);
        return ps.executeUpdate() > 0;
    } catch (Exception e) {
        e.printStackTrace();
    }
    return false;
}


    // Kurangi stok setelah transaksi
    public boolean kurangiStok(String barangId, int jumlah) {
        try (Connection conn = DbConnection.connect()) {
            String checkSql = "SELECT stok FROM barang WHERE id = ?";
            PreparedStatement checkPs = conn.prepareStatement(checkSql);
            checkPs.setString(1, barangId);
            ResultSet rs = checkPs.executeQuery();

            if (rs.next()) {
                int stokSekarang = rs.getInt("stok");
                if (stokSekarang < jumlah) {
                    return false; // Stok tidak cukup
                }
                int stokBaru = stokSekarang - jumlah;
                return updateStok(conn, barangId, stokBaru);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // Hapus barang dan relasi
    public boolean hapus() {
        try (Connection conn = DbConnection.connect()) {
            hapusRelasi(conn);
            String sql = "DELETE FROM barang WHERE id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, this.id);
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Ambil semua barang
    public static ArrayList<Barang> getList() {
        ArrayList<Barang> list = new ArrayList<>();
        try (Connection conn = DbConnection.connect()) {
            String sql = "SELECT * FROM barang ORDER BY nama";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Barang barang = new Barang();
                barang.id = rs.getString("id");
                barang.nama = rs.getString("nama");
                barang.jenis = rs.getString("jenis");
                barang.harga = rs.getInt("harga");
                barang.stok = rs.getInt("stok");
                list.add(barang);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Cek apakah ID barang sudah ada
    public static boolean isIdExists(String id) {
        try (Connection conn = DbConnection.connect()) {
            String sql = "SELECT COUNT(*) FROM barang WHERE id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // Dapatkan koneksi (jika dibutuhkan di luar)
    public Connection getKoneksi() {
        return DbConnection.connect();
    }

    // Total stok dari tabel stockd (stok awal/pembelian)
   // Tambahkan di class Barang
public static int getStokTersedia(String barangId) {
    int totalStok = 0;
    try (Connection conn = DbConnection.connect()) {
        String sql = "SELECT stok FROM barang WHERE id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, barangId);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            totalStok = rs.getInt("stok");
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return totalStok;
}

    @Override
    public String toString() {
        return "Barang{" +
                "id='" + id + '\'' +
                ", nama='" + nama + '\'' +
                ", jenis='" + jenis + '\'' +
                ", harga=" + harga +
                ", stok=" + stok +
                '}';
    }
}
