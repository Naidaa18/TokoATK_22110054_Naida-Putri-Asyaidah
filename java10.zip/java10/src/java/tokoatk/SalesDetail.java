package tokoatk;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class SalesDetail {
    private String id;
    private String salesId;
    private String barangId;
    private String barangNama;  // Nama barang supaya bisa ditampilkan di view
    private int qty;
    private int harga;
    private int total;

    // Getter & Setter
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getSalesId() { return salesId; }
    public void setSalesId(String salesId) { this.salesId = salesId; }

    public String getBarangId() { return barangId; }
    public void setBarangId(String barangId) { this.barangId = barangId; }

    public String getBarangNama() { return barangNama; }
    public void setBarangNama(String barangNama) { this.barangNama = barangNama; }

    public int getQty() { return qty; }
    public void setQty(int qty) { this.qty = qty; }
    
    public int getTotal(){return qty*harga;}


    public int getHarga() { return harga; }
    public void setHarga(int harga) { this.harga = harga; }

    

    // Method untuk ambil list detail berdasarkan salesId
    public static ArrayList<SalesDetail> getBySalesId(String salesId) {
    ArrayList<SalesDetail> list = new ArrayList<>();
    String sql = "SELECT d.*, b.nama AS barangNama FROM salesd d " +
                 "JOIN barang b ON d.barangId = b.id WHERE d.salesId = ?";
    try (Connection conn = DbConnection.connect();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, salesId);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            SalesDetail sd = new SalesDetail();
            sd.setId(rs.getString("id")); // kalau ada
            sd.setSalesId(rs.getString("salesId"));
            sd.setBarangId(rs.getString("barangId"));
            sd.setBarangNama(rs.getString("barangNama")); // PENTING!
            sd.setQty(rs.getInt("qty"));
            sd.setHarga(rs.getInt("harga"));
            list.add(sd);
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return list;
}

    // Method untuk baca detail berdasarkan salesId dan barangId
public boolean baca(String salesId, String barangId) {
    try {
        Connection conn = DbConnection.connect();

        String sql = "SELECT sd.*, b.nama FROM salesd sd JOIN barang b ON sd.barangid = b.id WHERE sd.salesid=? AND sd.barangid=?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, salesId);
        ps.setString(2, barangId);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            this.salesId = salesId;
            this.barangId = barangId;
            this.qty = rs.getInt("qty");
            this.harga = rs.getInt("harga");
            this.total = rs.getInt("qty") * rs.getInt("harga");

            this.barangNama = rs.getString("nama");
            return true;
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return false;
}

// Method untuk hapus detail berdasarkan salesId dan barangId
public boolean hapus() {
    try {
       Connection conn = DbConnection.connect();

        String sql = "DELETE FROM salesd WHERE salesid=? AND barangid=?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, this.salesId);
        ps.setString(2, this.barangId);
        int result = ps.executeUpdate();
        return result > 0;
    } catch (Exception e) {
        e.printStackTrace();
    }
    return false;
}

}
