package tokoatk;

import java.sql.*;
import java.util.ArrayList;

public class StockDetail {
    private int id;
    private String stockId;
    private String barangId;
    private int qty;
    private int harga;

    // Getter
    public int getId() {
        return id;
    }

    public String getStockId() {
        return stockId;
    }

    public String getBarangId() {
        return barangId;
    }

    public int getQty() {
        return qty;
    }

    public int getHarga() {
        return harga;
    }

    // Method tambahan: ambil nama barang
    public String getBarangNama() {
        try (Connection conn = DbConnection.connect()) {
            String sql = "SELECT nama FROM barang WHERE id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, barangId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getString("nama");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "-";
    }

    // Tambah data detail ke stockd
    public boolean tambah(String stockId, String barangId, int qty, int harga) {
        try (Connection conn = DbConnection.connect()) {
            String sql = "INSERT INTO stockd (stockId, barangId, qty, harga) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, stockId);
            ps.setString(2, barangId);
            ps.setInt(3, qty);
            ps.setInt(4, harga);
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // Ambil list detail berdasarkan stockId
    public static ArrayList<StockDetail> getListByStockId(String stockId) {
        ArrayList<StockDetail> list = new ArrayList<>();
        try (Connection conn = DbConnection.connect()) {
            String sql = "SELECT * FROM stockd WHERE stockId = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, stockId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                StockDetail detail = new StockDetail();
                detail.id = rs.getInt("id");
                detail.stockId = rs.getString("stockId");
                detail.barangId = rs.getString("barangId");
                detail.qty = rs.getInt("qty");
                detail.harga = rs.getInt("harga");
                list.add(detail);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
